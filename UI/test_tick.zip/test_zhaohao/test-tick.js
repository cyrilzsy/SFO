slidersHTML = '';
slidersHTML +=
          ' <input type="text" \
           id="sliderMinimumStock"> ';

slidersHTML +=
          '<div class="slidecontainer"> \
           <p><b> aaa </b> (Unit Price for Stores ($)): <span style="border:0; color:#f6931f; font-weight:bold;">6</span></p> \
           <input type="text" \
           id="ex13"> \
        </div >';

document.getElementById("test1").innerHTML = slidersHTML;
