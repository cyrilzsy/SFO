/**
 * Created by Siyao on 2018/7/20.
 */

// Variables for maximization
var n_max = 50;                                 // number of points for maximization

var z = {
  price:     null,
  M_profit:  null,
  M_storage: null,
  M_supply:  null,
  M_delivery:null,
  M_cust:    null,
  Y_supply:  null,
  S_actual:  null,
  Y_demand:  null,
  Y_cust:    null,
  Y_waste:   null
};
var zs       = [];
var z_length = Object.keys(z).length;
var z_plot   = {
  num_plots: null
};
var Pars     = [
                [
                  [0.0287,-0.0010,0.0535,-0.0015,-17.1916789793555,2.13233155747076/2,2.13233155747076/2,-0.449580277451484,0.616018158664077,-1.01968512168606,0.688871220878020,5.94064416342498,0.4550,0.0104,-0.0323, 2],    //Oranges·
                  [0.0287,-0.0010,0.0535,-0.0015,-4.79942516935125,1.16771704280577/2,1.16771704280577/2,0.485196091565435,-0.272337991283359,-0.175545380997276,-0.165992665719054,4.03882264716562,0.4550,0.0104,-0.0323, 2],    //Carrots·
                  [0.0287,-0.0010,0.0535,-0.0015,-7.33916186209473,0.914603202397955/2,0.914603202397955/2,,-0.476708389661922,-0.0307322745107076,-4.68388274420434,-0.00460346744482402,10.5531045735580,0.4550,0.0104,-0.0323, 2],    //Tomatoes·
                  [0.0287,-0.0010,0.0535,-0.0015,0,0.925835641257197/2,0.925835641257197/2,0.341684435237307,0,0.730548099176314,0,-1.39391399133855,0.4550,0.0104,-0.0323, 2],    //Bananas·
                  [0.2311,-0.0256,0.3443,-0.0291,1.98153626375764,-0.416985902465636/2,-0.416985902465636/2,-1.24235887251675,-0.183343364543090,-1.47745296876169,1.11425218798177,6.04780114358686,0.4550,0.0104,-0.0323, 5],    //CFJ·
                  [0.1455,-0.0062,0.3367,-0.0273,-12.2750552394942,0.676408575623010/2,0.676408575623010/2,0.311261472283016,0.577799242010191,-5.28878206932986,-1.48962552529271,14.4661664044135,0.5567,0.0565,-0.0237, 4],    // Broccoli·
                  [0.0818, 0.0057,0.1688, 0.0125,7.88092407396125,0.188261139288010/2,0.188261139288010/2,-1.85924138371096,-0.225958493720839,-1.74554880836488,0.566550859816798,4.82095590489600,0.4550,0.0104,-0.0323, 3]     //Lettuce·
                ],
                [
                  [0.1468, 0.0047,0.3324, 0.0003,-11.2421210312493,0.974174776257382/2,0.974174776257382/2,-0.169441354647301,0.199921566404308,0.650488779305542,1.16410115984648,3.95841453497570,0.8594,0.0713,-0.0442, 3],     //Whole Wheat Tortillas·
                  [0.6882,-0.0976,0.3383, 0.0527,-19.3687884863958,3.04444272483090/2,3.04444272483090/2,-0.653810367574350,-1.60822690002402,3.45319446059491,5.42427325427056,-8.24627290257315,0.4550,0.0104,-0.0323, 6],    //Oatmeal·
                  [0.6882,-0.0976,0.3383, 0.0527,-1.95616342569223,1.47665978477586/2,1.47665978477586/2,1.17630340163220,-0.0317842605429537,1.73129512338839,-1.65876694711682,-0.235965290632228,0.4550,0.0104,-0.0323, 6],    //Pasta·
                  [0.1468, 0.0047,0.3324, 0.0003,0,0.200330504445428/2,0.200330504445428/2,0,0.266767813469499,-3.55582883894655,-2.02866072014486,7.58106787783716,0.8594,0.0713,-0.0442, 3],     //Whole Wheat Bread·
                  [0.6882,-0.0976,0.3383, 0.0527,1.79407966656198,1.64456502124925/2,1.64456502124925/2,0.127742463500590,-0.594939808320696,1.45636995645343,0.0496252129285504,-0.869796742052425,0.4550,0.0104,-0.0323, 6]     //Cereal·
                ],
                [
                  [0.0507, 0.0498,0.3508, 0.0495,6.12718351590098,0.667015237391745/2,0.667015237391745/2,-1.78881832075392,-0.469817359363039,2.72280882955522,1.68427817458883,-6.17834064343492,1.6626,0.0485,-0.1052, 3],     //Yogurt·
                  [0.1378,-0.0017,0.3385,-0.0202,7.49726428449615,0.171815066958423/2,0.171815066958423/2,0.0845028988075608,0.385840540195447,4.16997451584189,1.22741359530567,-6.32030573035420,1.6626,0.0104,-0.0323, 3],     // Cheese·
                  [0.0507, 0.0498,0.3508, 0.0495,-8.06942863316111,0.392206574867759/2,0.392206574867759/2,-0.247566301979059,0.894952666158551,-1.95751154522644,1.19166054556667,2.53961354220508,1.6626,0.0485,-0.1052, 3]     //FFM·
                ],
                [
                  [0.1410,-0.0108,0.2881,-0.0252,-5.35338977803970,-0.667555949500404/2,-0.667555949500404/2,-0.704859437139618,2.53042946536775,2.10305798437064,1.40717419257256,-2.54555667118113,0.4550,0.0104,-0.0323, 2],    //Beef·
                  [0.1410,-0.0108,0.2881,-0.0252,9.07698852028666,0.392463558300354/2,0.392463558300354/2,0.0372217509122189,0.726211880354084,7.24209943455725,1.29678775009453,-6.24719799598041,0.4550,0.0104,-0.0323, 2],    //Poultry·
                  [0.1410,-0.0108,0.2881,-0.0252,3.47458056580927,-0.574470891232594/2,-0.574470891232594/2,0.724576717939880,0.469197125747056,2.98001566532698,0.955827317270812,-6.53231705944642,0.4550,0.0104,-0.0323, 4],     //CT·
                  [0.1378,-0.0017,0.3385,-0.0202,5.41413485942048,0.926707578866694/2,0.926707578866694/2,-0.133786068203111,0.786333184001281,2.33927904775327,-0.917627885931690,-3.17918301367342,1.6626,0.0485,-0.1052, 3]     // Eggs·
                ],
                [
                  [0.1511,-0.0352,0.1864,-0.0352,3,0.14,0.18,0.15,0.18,0.17,0.13,3.875,0.4550,0.0104,-0.0323, 1],     //Peanut Butter
                  [0.0507, 0.0498,0.3508, 0.0495,3,0.15,0.19,0.19,0.16,0.15,0.11,1.410,1.6626,0.0485,-0.1052, 3],     //Soymilk
                  [0.1544,-0.0134,0.3464,-0.0375,2,0.18,0.11,0.20,0.14,0.13,0.19,1.350,0.4690,0.1291,-0.0098,6]       //Canned Beans
                ]
               ];



function evalSliders(iFood) {
   let Enforcement   = sliders.currentValues[iFood[0]][iFood[1]][0][0];
   let Training      = sliders.currentValues[iFood[0]][iFood[1]][0][1];
   let Signage       = sliders.currentValues[iFood[0]][iFood[1]][0][2];
   let S_required    = sliders.currentValues[iFood[0]][iFood[1]][0][3];
   let Convenience   = sliders.currentValues[iFood[0]][iFood[1]][1][0];
   let Taste         = sliders.currentValues[iFood[0]][iFood[1]][1][1];
   let Affordability = sliders.currentValues[iFood[0]][iFood[1]][1][2];
   let Healthiness   = sliders.currentValues[iFood[0]][iFood[1]][1][3];
   let S_infra       = sliders.currentValues[iFood[0]][iFood[1]][2][0];
   let X_delivery    = sliders.currentValues[iFood[0]][iFood[1]][2][1];
   let C_store       = sliders.currentValues[iFood[0]][iFood[1]][2][2];         // take out price
   let Par           = Pars[iFood[0]][iFood[1]];
  runOptimal(Enforcement,Training,Signage,Convenience,Taste,Affordability,Healthiness,S_infra,S_required,X_delivery,C_store,Par);
  for (key in z) {
    food.results[key][iFood[0]][iFood[1]] = z[key];                             // z is not an array
  }
}


function runOptimal(Enforcement,Training,Signage,Convenience,Taste,Affordability,Healthiness,S_infra,S_required,X_delivery,C_store,Par) {
  let C_delivery = Par[0] + X_delivery*Par[1];
  let C_storage  = Par[2] + Par[3]*S_infra;
  let y_0        = Par[4] + Par[5]*Training      + Par[6]*Signage + Par[7]*Convenience + Par[8]*Taste
                          + Par[9]*Affordability + Par[10]*Healthiness;
  let a          = Par[11];
  let M_profit_max = -10000;
  let Y_demand   = null;
  let C_cust_max = y_0/a;                        // maximum cost for the customer (x-intercept of the demand curve)
  let C_custj    = null;
  let j_max      = null;

  for (j = 0; j < n_max; j++) {
    C_custj   = C_cust_max*j/n_max;           // price for the customer
    S_expire  = Enforcement*S_required/Par[15];           // maximum amount of food that can expire each week
    Y_demand  = y_0 - C_custj*a;              // demand
    if        (Y_demand  > Enforcement*S_required) {
      M_profit = (C_custj - C_delivery - C_store - C_storage)*Y_demand;
    }
    else if (((Y_demand <= Enforcement*S_required)) && ((S_expire) <= Y_demand)) {
      M_profit = (C_custj - C_delivery - C_store)*Y_demand - C_storage*Enforcement*S_required;
    }
    else {
      M_profit = (C_custj)*Y_demand - C_storage*Enforcement*S_required - (C_store + C_delivery)*S_expire;
    }
    if (M_profit > M_profit_max) {            // update the maximum profit
      j_max      = j;                         // index j corresponding to the maximum profit
      z.M_profit = M_profit;                  // set the z key values
      z.Y_demand = Y_demand;
      z.price    = C_custj;
      M_profit_max = M_profit;
    }
    z.S_actual   = Math.max(Enforcement*S_required,z.Y_demand);    // set the remaining z key values
    z.Y_supply   = Math.max(z.Y_demand,S_expire);
    z.Y_cust     = z.Y_demand;
    z.Y_waste    = Math.max(S_expire-z.Y_demand,0);
    z.M_storage  = z.S_actual*C_storage;
    z.M_supply   = z.Y_supply*(C_store + C_delivery);
    z.M_delivery = z.Y_supply*C_delivery;
    z.M_cust     = z.Y_demand*z.price
  }

}


